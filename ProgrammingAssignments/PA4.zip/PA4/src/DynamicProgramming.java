import java.util.ArrayList;

public class DynamicProgramming {

	public static int numberOfBinaryStringsWithNoConsecutiveOnes(int n) {
		int x = 1;
		int y = 1;
		int temp = 0;

		for(int i = 1; i < n; i++) {
			temp = x;
			x = x + y;
			y = temp;
		}

		return x + y; 
	}

	public static ArrayList<Integer> longestIncreasingSubsequence(int[] arr, int len) {
		int lis[] = new int[len];
		int pred[] = new int[len];
				
		for(int i = 0; i < len; i++) {
			lis[i] = 1;
			pred[i] = i;
		}

		for(int i = 0; i < len; i++) {
			for(int j = 0; j < i; j++) {
				if(arr[i] > arr[j]) {
					if(lis[j] + 1 > lis[i]) {
						lis[i] = lis[j] + 1;
						pred[i] = j;
					}
				}
			}
		}

		int maxIndex = 0;
		for(int i = 0; i < len; i++) {
			if(lis[i] > lis[maxIndex]) { maxIndex = i; }
		}

		ArrayList<Integer> dynamicArray = new ArrayList<>();
		int lisIndex = maxIndex;
		dynamicArray.add(arr[lisIndex]);
		int temp = pred[lisIndex];

		while(lisIndex != temp) {
			lisIndex = temp;
			dynamicArray.add(arr[lisIndex]);
			temp = pred[lisIndex];
		}

		reverse(dynamicArray);
		return dynamicArray;
	}

	private static void reverse(ArrayList<Integer> list) {
		for (int i = 0, j = list.size() - 1; i < j; i++, j--) {
			int temp = list.get(j);
			list.set(j, list.get(i));
			list.set(i, temp);
		}
	}
}
