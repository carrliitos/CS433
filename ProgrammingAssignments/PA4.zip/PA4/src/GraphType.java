public enum GraphType {
	UNWEIGHTED,
	WEIGHTED
}
